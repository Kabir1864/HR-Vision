const FreeCard = () => {
  return (
   <></>
  );
};

export default FreeCard;
