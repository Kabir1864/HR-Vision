import FeedbackForm from "components/feedbackform/FeedbackForm";
import React from "react";

const index = () => {
  return (
    <div>
      <FeedbackForm />
    </div>
  );
};

export default index;
