import React from "react";

const PageNotFound = () => {
  return <div className="m-10">Page Not Found</div>;
};

export default PageNotFound;
